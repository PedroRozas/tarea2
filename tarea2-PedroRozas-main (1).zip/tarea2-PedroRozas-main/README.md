# tarea2-PedroRozas
tarea2-PedroRozas created by GitHub Classroom
Apache netbeans me reconocio automaticamente la fuente custom que agregue, es una fuente de numeros digitales y casi todos los labels estan configurados con el.
Revisar bien si esta reconociendo la fuente al momento de iniciar
