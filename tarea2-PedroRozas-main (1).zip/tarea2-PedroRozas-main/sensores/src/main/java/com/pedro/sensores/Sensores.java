/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.pedro.sensores;

/**
 *
 * @author proza
 */
public class Sensores {

    public static void main(String[] args) {
        new login().setVisible(true);
    }
}
